return @(
  "deregister-from --instance Tentacle --server http://localhost:81 --apiKey API-1234 --console"
)
