return @{
  Ensure = "Absent";
  State = "Stopped"
}
